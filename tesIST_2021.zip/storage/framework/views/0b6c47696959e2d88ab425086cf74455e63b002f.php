

<?php $__env->startSection('judul','Data Soal - Halaman Admin'); ?>

<?php $__env->startSection('isi'); ?>
<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
        <div class="sidebar-brand-text mx-3">Tes IST 2021</div>
    </a>

    <hr class="sidebar-divider my-0">            
    <div class="sidebar-heading">Menu</div>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('data-peserta')); ?>"><i class="fas fa-users "></i>
            <span >Data Peserta</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('data.soal')); ?>"><i class="fas fa-book text-white"></i>
            <span class="text-white">Data Soal</span>
        </a>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="ubahPassword.php"><i class="fas fa-exchange-alt"></i>
            <span>Ubah Password</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="rekap/rekap.php"><i class="fas fa-book-reader"></i>
            <span>Lihat Hasil Tes</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" data-toggle="modal" data-target="#logoutModal" href="#"><i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
        <!-- Topbar -->
        <?php echo $__env->make('admin_pages.master-admin.navAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Content Row -->
            <div class="row">
                <div class="col">
                    <a class="badge badge-success mb-3" href="<?php echo e(route('viewTambah.sub6')); ?>">Insert Soal</a>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between text-dark">
                            <h4>Subtes 6 ( Tes Deret Angka )</h4>
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <table class="table">
                                <thead class="thead-dark">
                                    <tr>
                                        <th scope="col">Id</th>
                                        <th scope="col">Soal Subtes 1</th>
                                        <th scope="col">Jawaban Soal</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $sub6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($item->idsoal_t6); ?></th>
                                        <td><?php echo e($item->keterangan_t6); ?></td>
                                        <td><?php echo e($item->t6_jawaban); ?></td>
                                        <td>
                                            <a class="btn btn-primary" href="/admin/data-soal/subtes6/edit/<?php echo e($item->idsoal_t6); ?>">Edit</a>
                                            <a class="btn btn-danger" href="/admin/data-soal/subtes6/hapus/<?php echo e($item->idsoal_t6); ?>">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
    <!-- Footer -->
    <?php echo $__env->make('master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->
</div>
    
<?php $__env->stopSection(); ?>







<?php echo $__env->make('admin_pages.master-admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Semester_6\Folder_aplikasi_KP\bismillah-implementasi-part2\tesIST_2021\resources\views/admin_pages/data_soal/sub6/index.blade.php ENDPATH**/ ?>