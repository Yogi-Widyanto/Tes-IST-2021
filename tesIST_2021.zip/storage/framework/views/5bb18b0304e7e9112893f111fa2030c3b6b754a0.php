

<?php $__env->startSection('judul','Data Soal - Halaman Admin'); ?>

<?php $__env->startSection('isi'); ?>
<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
        <div class="sidebar-brand-text mx-3">Tes IST 2021</div>
    </a>

    <hr class="sidebar-divider my-0">            
    <div class="sidebar-heading">Menu</div>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('data-peserta')); ?>"><i class="fas fa-users "></i>
            <span >Data Peserta</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('data.soal')); ?>"><i class="fas fa-book text-white"></i>
            <span class="text-white">Data Soal</span>
        </a>
    </li>
   
    <li class="nav-item">
        <a class="nav-link collapsed" href="ubahPassword.php"><i class="fas fa-exchange-alt"></i>
            <span>Ubah Password</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="rekap/rekap.php"><i class="fas fa-book-reader"></i>
            <span>Lihat Hasil Tes</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" data-toggle="modal" data-target="#logoutModal" href="#"><i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
        <!-- Topbar -->
        <?php echo $__env->make('admin_pages.master-admin.navAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Content Row -->
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form action="<?php echo e(route('update.sub7')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php
                                    $opsi='for-subtes/image_tes/'.$item->mainSoal_t7;
                                    $soal='for-subtes/image_tes/'.$item->keterangan_t7;
                                ?>
                                <input type="hidden" name="id" value="<?php echo e($item->idsoal_t7); ?>"> <br/>
                                <input type="hidden" name="opsiSoalSave" value="<?php echo e($item->mainSoal_t7); ?>"> <br/>
                                <input type="hidden" name="soalSave" value="<?php echo e($item->keterangan_t7); ?>"> <br/>
                                <div class="form-group">
                                    <label for="opsi">Pilihan Opsi</label>
                                    <input id="opsi" class="form-control" type="text" name="opsi" value="<?php echo e($item->mainSoal_t7); ?>" readonly>
                                </div>

                                <div class="form-group">
                                    <img src="<?php echo e(asset($opsi)); ?>" alt="<?php echo e(asset($opsi)); ?>" sizes="">
                                </div>

                                <div class="form-group">
                                    <label for="soal">Soal</label>
                                    <input id="soal" class="form-control" type="text" name="soal" value="<?php echo e($item->keterangan_t7); ?>" readonly>
                                </div>

                                <div class="form-group">
                                    <img src="<?php echo e(asset($soal)); ?>" alt="<?php echo e(asset($soal)); ?>" sizes="">
                                </div>
                                
                                <div class="form-group">
                                    <label for="t6_jawaban">Jawaban Soal</label>
                                    <input id="t6_jawaban" class="form-control" type="text" name="lihatjwb" value="<?php echo e($item->t7_jawaban); ?>" readonly>
                                </div>

                                <hr>
                                <div class="form-group">
                                    <label for="updateOpsi">Pilihan Opsi <span class="font-italic">( abaikan jika menggunakan opsi diatas )</span></label>
                                    <input id="updateOpsi" class="form-control" type="file" name="updateOpsi">
                                    <?php if(session('file')): ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Ukuran File</strong> Terlalu Besar
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <?php elseif(session('file3')): ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Format Extension File</strong> Tidak Sesuai
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="updateSoal">Soal <span class="font-italic">( abaikan jika menggunakan opsi diatas )</span></label>
                                    <input id="updateSoal" class="form-control" type="file" name="updateSoal">
                                    <?php if(session('file2')): ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Ukuran File</strong> Terlalu Besar
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <?php elseif(session('file4')): ?>
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Format Extension File</strong> Tidak Sesuai
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="t6_jawaban">Jawaban Soal</label>
                                    <input id="t6_jawaban" class="form-control" type="text" name="jwb" required>
                                </div>

                                <div class="form-group">
                                    <input type="submit" value="Update" class="btn btn-primary">
                                </div>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
    <!-- Footer -->
    <?php echo $__env->make('master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->
</div>
    
<?php $__env->stopSection(); ?>







<?php echo $__env->make('admin_pages.master-admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Semester_6\Folder_aplikasi_KP\bismillah-implementasi-part2\tesIST_2021\resources\views/admin_pages/data_soal/sub7/edit.blade.php ENDPATH**/ ?>