<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>logout</title>
</head>
<body>
    <a href="<?php echo e(route ('logout')); ?>">Keluar</a>
    
    <?php
        echo $data;
        echo $data2;

    ?>

</body>
</html><?php /**PATH F:\Semester_6\Folder_aplikasi_KP\bismillah-implementasi-part2\tesIST_2021\resources\views/sukses.blade.php ENDPATH**/ ?>