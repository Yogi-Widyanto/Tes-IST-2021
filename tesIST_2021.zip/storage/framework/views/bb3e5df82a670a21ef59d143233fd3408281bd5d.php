

<?php $__env->startSection('judul','Data Peserta - Halaman Admin'); ?>

<?php $__env->startSection('isi'); ?>
<ul class="navbar-nav bg-gradient-dark sidebar sidebar-dark accordion" id="accordionSidebar">
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">
        <div class="sidebar-brand-text mx-3">Tes IST 2021</div>
    </a>

    <hr class="sidebar-divider my-0">            
    <div class="sidebar-heading">Menu</div>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('data-peserta')); ?>"><i class="fas fa-users "></i>
            <span >Data Peserta</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('data.soal')); ?>"><i class="fas fa-book text-white"></i>
            <span class="text-white">Data Soal</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="soal/tambah_soal.php"><i class="fas fa-folder-plus"></i>
            <span>Tambah Soal</span>
        </a>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="ubahPassword.php"><i class="fas fa-exchange-alt"></i>
            <span>Ubah Password</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="rekap/rekap.php"><i class="fas fa-book-reader"></i>
            <span>Lihat Hasil Tes</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" data-toggle="modal" data-target="#logoutModal" href="#"><i class="fas fa-sign-out-alt"></i>
            <span>Logout</span>
        </a>
    </li>
    <hr class="sidebar-divider d-none d-md-block">
</ul>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
    <!-- Main Content -->
    <div id="content">
        <!-- Topbar -->
        <?php echo $__env->make('admin_pages.master-admin.navAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Content Row -->
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-4">
                        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                        </div>
                        <!-- Card Body -->
                        <div class="card-body">
                            <h4>Tambah Soal Untuk Subtes 1</h4>
                            <form action="<?php echo e(route('tambah.sub1')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="soal">Soal</label>
                                    <input id="soal" class="form-control" type="text" name="soal" >
                                </div>

                                <div class="form-group">
                                    <label for="opsia">Opsi A</label>
                                    <input id="opsia" class="form-control" type="text" name="opsia" >
                                </div>

                                <div class="form-group">
                                    <label for="opsib">Opsi B</label>
                                    <input id="opsib" class="form-control" type="text" name="opsib" >
                                </div>

                                <div class="form-group">
                                    <label for="opsic">Opsi C</label>
                                    <input id="opsic" class="form-control" type="text" name="opsic" >
                                </div>

                                <div class="form-group">
                                    <label for="opsid">Opsi D</label>
                                    <input id="opsid" class="form-control" type="text" name="opsid" >
                                </div>

                                <div class="form-group">
                                    <label for="opsie">Opsi E</label>
                                    <input id="opsie" class="form-control" type="text" name="opsie" >
                                </div>

                                <div class="form-group">
                                    <label for="t1_jawaban">Jawaban Soal</label>
                                    <input id="t1_jawaban" class="form-control" type="text" name="jwb" >
                                </div>

                                <div class="form-group">
                                    <input type="submit" value="Update" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->
    <!-- Footer -->
    <?php echo $__env->make('master.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->
</div>
    
<?php $__env->stopSection(); ?>







<?php echo $__env->make('admin_pages.master-admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Semester_6\Folder_aplikasi_KP\bismillah-implementasi-part2\tesIST_2021\resources\views/admin_pages/data_soal/sub1/tambah.blade.php ENDPATH**/ ?>