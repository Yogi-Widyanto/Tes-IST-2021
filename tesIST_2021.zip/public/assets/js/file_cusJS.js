function mulaites() {
    window.location.href="tes_T1/tes_T1.php";
}