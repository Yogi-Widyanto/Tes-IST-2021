<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto"> <span>Copyright &copy; Tes IST 2021</span>
        </div>
    </div>
</footer>

<a class="scroll-to-top rounded" href="#page-top"> <i class="fas fa-angle-up"></i>
</a>
    
