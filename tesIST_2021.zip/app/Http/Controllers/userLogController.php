<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Subtes_1;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;


class userLogController extends Controller
{
    // untuk daftar/register akun
    public function daftar (){
        return view ('user_pages.userRegister');
    }

    public function saveData (Request $request){
        $validated = $request->validate([
            'namaLengkap' => 'required|max:120|alpha',
            'email' => 'required|unique:users,email|email:rfc,dns',
            'password' => 'required|min:8|alpha_num',
        ]);

        User::create ([
            'nama_lengkap' => $request->namaLengkap,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);
        return redirect('/login');

    }

    //untuk login
    public function viewLogin (Request $request){
        if ($request->session()->has('petunjuk-pengerjaan')) {
            return redirect('/petunjuk-tes');
        }
        if ($request->session()->has('soal_1')) {
            return redirect('/subtes-1');
        }
        if ($request->session()->has('soal_2')) {
            return redirect('/subtes-2');
        }
        if ($request->session()->has('soal_3')) {
            return redirect('/subtes-3');
        }
        if ($request->session()->has('soal_4')) {
            return redirect('/subtes-4');
        }
        if ($request->session()->has('soal_5')) {
            return redirect('/subtes-5');
        }
        if ($request->session()->has('soal_6')) {
            return redirect('/subtes-6');
        }
        if ($request->session()->has('soal_7')) {
            return redirect('/subtes-7');
        }
        if ($request->session()->has('soal_8')) {
            return redirect('/subtes-8');
        }
        if ($request->session()->has('soal_9')) {
            return redirect('/subtes-9');
        }
        


        return view ('user_pages.userLogin');
    }

    public function cekLogin (Request $request){
        $cekEmail = DB::table('users')
                    ->where('email', '=', $request->email)
                    ->get();
        
        $status='';
        $savePassword='';
        $iduser='';
        $email='';

        foreach ($cekEmail as $key) {
            $status=$key->keteranganTes;
            $savePassword= $key->password;
            $iduser=$key->id_user;
            $email=$key->email;
        }
        if ($status == "Belum Selesai") {
            if (count($cekEmail)==1) {
                if (Hash::check($request->password, $savePassword)) {
                    session(['petunjuk-pengerjaan' => 'petunjuk-pengerjaan']);
                    session(['idUser' => $iduser]);
                    session(['email' => $email]);
                    // session(['soal_9' => "soal 9"]);
                    // return redirect('/subtes-9');
                    return redirect('/petunjuk-tes');
                }else {
                    return redirect('/login')->with('erorPassword','Password Salah');
                }
            }else{
                return redirect('/login')->with('erorEmail','Email Salah');
            }
        }else {
            if (count($cekEmail)==1) {
                if (Hash::check($request->password, $savePassword)) {
                    session(['idUser' => $iduser]);
                    session(['email' => $email]);
                    return redirect('/selesai');
                }else {
                    return redirect('/login')->with('erorPassword','Password Salah');
                }
            }else{
                return redirect('/login')->with('erorEmail','Email Salah');
            }
        }

    }

    public function logout (Request $request){
        $request->session()->flush();
        return redirect('/login');
    }

    public function petunjukTes (Request $request){
        if ($request->session()->has('petunjuk-pengerjaan')) {
            return view('user_pages.hint-tes.index');
        }
        return redirect('/');
    }

    public function selesai (Request $request){
        return view ('user_pages.selesai');
    }
    
}

