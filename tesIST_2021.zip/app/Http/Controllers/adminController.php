<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Admin;
use App\Models\tanggalTes;
use App\Models\User;
use App\Models\Subtes_1;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class adminController extends Controller
{

    // Admin login
    public function viewAdminLogin(){
        return view ('admin_pages.adminLogin');
    }
    public function cekAdminLogin (Request $request){
        $cekEmail = DB::table('admins')
                    ->where('email_admin', '=', $request->email)
                    ->get();
        
        $savePassword='';
        $idAdmin='';
        $emailAdmin='';

        foreach ($cekEmail as $key) {
            $savePassword= $key->password_admin;
            $idAdmin=$key->id_admin;
            $emailAdmin=$key->email_admin;
        }
        if (count($cekEmail)==1) {
            if (Hash::check($request->password, $savePassword)) {
                session(['idAdmin' => $idAdmin]);
                session(['email_admin' => $emailAdmin]);
                return redirect('admin/home');
            }else {
                return redirect('admin/login')->with('erorPassword','Password Salah');
            }
        }else{
            return redirect('admin/login')->with('erorEmail','Email Salah');
        }

    }

    public function home(){
        return view ('admin_pages.index');
    }

    public function logout (Request $request){
        $request->session()->flush();
        return redirect('/');
    }


    public function dataPeserta(Request $request){
        $dataPeserta=User::paginate(10);
        return view ('admin_pages.data-peserta',['dataPeserta' => $dataPeserta]);
    }
    
    public function editData($id){
        $data=DB::table('users')->where('id_user',$id)->get();
        return view('admin_pages.edit_dataPeserta',['data' => $data]);
        
    }

    public function updateData(Request $request){
        DB::table('users')->where('id_user',$request->id)->update([
            'nama_lengkap' => $request->nama_lengkap,
            'email' => $request->email,
            'keteranganTes' => $request->ket
        ]);
        return redirect('/admin/data-peserta');
    }

    public function hapusData($id){
        DB::table('users')->where('id_user',$id)->delete();
        return redirect('/admin/data-peserta');
        
    }


    //data soal
    public function dataSoal(){
        return view ('admin_pages.data_soal.dataSoal');
    }

    // ubah password
    
    public function viewUbahPassword(Request $request){
        $idAdmin=$request->session()->get('idAdmin');
        $data=DB::table('admins')->where('id_admin',$idAdmin)->get();
        return view('admin_pages.ubahPassword',['data' => $data]);
        
    }

    public function UbahPassword(Request $request){
        if (($request->password2) == ($request->password3)) {
            DB::table('admins')->where('id_admin',$request->id)->update([
                'password_admin' => Hash::make($request->password2)
            ]);
            return redirect('/admin/home');
        }else {
            return redirect('/admin/ubah-password')->with('passwordBeda','Password Beda');
        }


    }

    //tgl tes

    public function viewTgl(Request $request){

        $data=DB::table('tanggal_tes')->get();
        return view('admin_pages.tanggaltes',['data' => $data]);
        
    }

}
